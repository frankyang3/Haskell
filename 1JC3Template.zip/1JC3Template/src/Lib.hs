module Lib
    ( someString
    ) where

someString :: String
someString = "Hello World!"
